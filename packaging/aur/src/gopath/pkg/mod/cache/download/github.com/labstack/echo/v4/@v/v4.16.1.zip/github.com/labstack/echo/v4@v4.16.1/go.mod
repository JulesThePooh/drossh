module github.com/labstack/echo/v4

go 1.26.0

require (
	github.com/labstack/gommon v0.5.0
	github.com/stretchr/testify v1.11.1
	github.com/valyala/fasttemplate v1.2.2
	golang.org/x/crypto v0.57.0
	golang.org/x/net v0.60.0
	golang.org/x/time v0.15.0
)

require (
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/mattn/go-colorable v0.1.15 // indirect
	github.com/mattn/go-isatty v0.0.22 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	github.com/valyala/bytebufferpool v1.0.0 // indirect
	golang.org/x/sys v0.48.0 // indirect
	golang.org/x/text v0.42.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)
